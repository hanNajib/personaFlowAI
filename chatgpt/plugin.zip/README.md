# PersonaFlow AI

A skills-only plugin for personalized activity matching. It asks for four preferences and recommends at most three entries using only the bundled fictional catalog.

## Files
- `plugin.json`: plugin identity and presentation.
- `skills/activity-recommender/SKILL.md`: reusable workflow and strict matching rules.
- `skills/activity-recommender/references/persona_catalog.json`: sole source of activity recommendation facts.
- `skills/activity-recommender/agents/openai.yaml`: skill interface metadata.

## Constraints
- No API, database, website, login, or external integration.
- Numeric budget is a hard cap. A cost range crossing the cap is not verified as affordable.
- All activities are fictional portfolio-demo data, not real offers.
- Personalized recommendations require interest, maximum budget in IDR, available duration, and desired mood.
